CREATE TABLE log_attempts (
   usrname     VARCHAR2(10),
   success     NUMBER(1),
   log_time    DATE 
);

