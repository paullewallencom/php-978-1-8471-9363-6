<?php
  //File: hrCred.php
  $user="hr";
  $pswd="hr";
  $conn="(DESCRIPTION=
         (ADDRESS_LIST=
           (ADDRESS=(PROTOCOL=TCP)(HOST=localhost)(PORT=1521))
          )
         (CONNECT_DATA=(SID=orcl)(SERVER=DEDICATED))
       )";
?>
