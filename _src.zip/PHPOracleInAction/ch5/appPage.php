<?php
  //File: appPage.php
  require_once "testAuth.php";               
  $thisPage='"'."appPage.php".'"';
  print "Click <a href=".$thisPage.">here</a> to reload this page"; 
?>
