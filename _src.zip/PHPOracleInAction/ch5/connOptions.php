<?php
  //File: connOptions.php
  $auth_opts = array(
   'dsn'=>'oci8://usr:usr@localhost:1521/orcl',
   'table'=>'accounts',
   'usernamecol'=>'usr_id',
   'passwordcol'=>'pswd',
   'db_fields' => '*'
  );
?>
